import java.sql.SQLOutput;
import java.util.Scanner;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {


        //String speed = "hight";

        //int variable = 123456;


        //System.out.println(variable);

        //int a = 0;
        //int b = 0;
        //a = 2;
        //int c = b;

        //System.out.println("a = " + a);
        //System.out.println("b = " + b);
        //System.out.println("c = " + c);

        //boolean turnedOn = true;
        //turnedOn = false;
        //String turnedOff = "turnedOn";
        //System.out.println(turnedOff);

        //float aFloat = 23.75f;
        //String string = "Hoy hay salmon con: ";
        //char cher = ',';
        //System.out.println(string + " patatas " + cher);
        //System.out.println(string + " palos " + cher);

        //int y = 2020;
        //String m = "Abril";
        //float t = 37.5f;
        //boolean s = false;
        //char c = ';';

        //System.out.println(y);
        //System.out.println(m);
        //System.out.println(t);
        //System.out.println(s);
        //System.out.println(c);

        /*boolean a = true;
        float b = 35.6f;
        float c = 2000.0f;
        String d = "true";
        char e1 = 't', e2 = 'r', e3 = 'u', e4 = 'e';

        System.out.println(a);
        System.out.println(b);
        System.out.println(c);
        System.out.println(d);
        System.out.print(e1);
        System.out.print(e2);
        System.out.print(e3);
        System.out.print(e4);*/

        Scanner teclado = new Scanner(System.in);

        /*
        System.out.println("Como te llamas?");
        String nom = teclado.nextLine();
        System.out.println(" Hola " + nom + "!");

        System.out.println(" Dime cualquier frase: ");


        String paraula1 = teclado.next();
        String paraula2 = teclado.next();
        String paraula3 = teclado.next();
        String paraula4 = teclado.next();
        String paraula5 = teclado.next();


        System.out.println (paraula1 + "\n"+ paraula2 + "\n" + paraula3 + "\n" + paraula4 + "\n" + paraula5);


        System.out.println("Dime tu nombre: ");
        String paraula1 = teclado.next();
        System.out.println("Dime tu edad: ");
        String paraula2 = teclado.next();
        System.out.println("Dime tus estudios: ");
        String paraula3 = teclado.next();
        System.out.println("Dime cuants anys de estudis: ");
        String paraula4 = teclado.next();
        System.out.println("Tipus de ofici de cuina: ");
        String paraula5 = teclado.next();




        System.out.println("El formulari de " + paraula1 + " s'ha completat. " + " Et contactare si necessitem un xef de cuina " + paraula5);


        System.out.println("Senyor o senyora? ");
        String paraula1 = teclado.next();
        System.out.println("Dime tu nombre: ");
        String paraula2 = teclado.next();
        System.out.println("Dime tu primer apellido: ");
        String paraula3 = teclado.next();
        System.out.println("Dime tu segundo apellido: ");
        String paraula4 = teclado.next();

        System.out.println( paraula1 + " " + paraula3 + " " + paraula4 + " , " + paraula2);
        System.out.println("El principal objetivo de la presente carta... ");

*/
        System.out.println("Com et dius?");
        String nombre = teclado.nextLine();
        System.out.println("Quants anys tens?");
        String edad = teclado.next();
        System.out.println("On vius?");
        String lugar = teclado.next();
        System.out.println("Quin sou mensual tens?");
        String sou = teclado.next();
        System.out.println("Quina es la teua professio?");
        String professio = teclado.next();

        System.out.println("FITXA PERSONAL");
        System.out.println("Nom: " + nombre);
        System.out.println("Localitat: " + lugar);
        System.out.println("Sou: " + sou);
        System.out.println("Professio: " + professio);


    }
}
//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
import java.util.Scanner;
public class Main {
    public static void main(String[] args) {

        Scanner teclado = new Scanner(System.in);

        /*//Ejercicio1
        //a
        System.out.println( 2 + 3 * 4 + 5);
        //b
        System.out.println(2 + (-3) + 5 + (-8));
        //d
        System.out.println((-5) * (-10) * (-20));
        //f
        System.out.println(3 / 2f);
        //g
        System.out.println(( 5 / 2) * (5 / 2));
        System.out.println((5 / 2) * (5f / 2));

        //Ejercicio2
        //a
        System.out.println("Hola " + "mon");
        System.out.println("Hola " + 330);
        System.out.println("Hola " + 'm' + 'o' + 'n');
        System.out.println("Hola " + ('m' + 'o' + 'n'));
        System.out.println('m' + 'o' + 'n' + "Hola");
        //b
        int a = 2;
        int b = 3;
        System.out.println("" + a + b);
        System.out.println("" + a * b);
        System.out.println(a * b + "");
        System.out.println(a + b + "");
        //System.out.println(a + "" * b);//No son valides
        //System.out.println(a * "" + b);//No son valides

        //Ejercicio3
        //a
        int a = 4, b = 6;
        int c = a + b;0
        int result = c + (a + b) * c;
        System.out.println(result);

        //Ejercicio4
        int espai = 1000;
        float temps = 4.4f;
        float velocitat = espai / temps;
        System.out.println(velocitat);

        //Ejercicio5
        //a
        float tercio = teclado.nextFloat() / 3;
        System.out.println(tercio);
        //b
        int a = 5 / 2;
        float b = a / 2;
        System.out.println(b);
        System.out.println("\uD83C\uDF88\uD83E\uDD21");

        //Ejercicio6
        System.out.println("Cuantas ardillas hay?");
        int ardilla = teclado.nextInt();
        System.out.println("Cuantas nueces hay?");
        int nueces = teclado.nextInt();
        System.out.println("Hay estas nueces repartidas para cada ardilla: ");
        System.out.println( nueces / ardilla );

        //Ejercicio7
        System.out.println("Cuantos autobuses disponibles hay en la primera empresa? ");
        int A = teclado.nextInt();
        System.out.println("Cuantos autobuses disponibles hay en la segunda empresa? ");
        int B = teclado.nextInt();
        System.out.println("Cual es la capacidad maxima de los autobuses? ");
        int N = teclado.nextInt();
        System.out.println("Hay " + ( A + B) * N + " plazas disponibles.");

        //Ejercicio8
        System.out.println("Dime la nota de tu primer examen: ");
        float N1 = teclado.nextFloat();
        System.out.println("Dime la nota de tu segundo examen: ");
        float N2 = teclado.nextFloat();
        System.out.println("Dime la nota de tu tercer examen: ");
        float N3 = teclado.nextFloat();
        System.out.println("Tu media es: " + (N1 + N2 + N3) / 3);

        //Ejercicio9
        System.out.println("Dime los ejes horizontales ");
        int ax = teclado.nextInt();
        int ay = teclado.nextInt();
        System.out.println("Dime los ejes verticales ");
        int bx = teclado.nextInt();
        int by = teclado.nextInt();
        System.out.println("Su perimetro es " + (((ax - bx ) * 2 + ( ay - by ) * 2)) );

        //Ejercicio10
        System.out.println(" Cuantos insecto hay?");
        int I = teclado.nextInt();
        System.out.println(" Cuantos aracnidos hay?");
        int A = teclado.nextInt();
        System.out.println(" Cuantos crustaceos hay?");
        int C = teclado.nextInt();
        System.out.println(" Cuantos Mirapodes hay de 2 patas?");
        int M2 = teclado.nextInt();
        System.out.println(" Cuantos segmentos tienen?");
        int S2 = teclado.nextInt();
        System.out.println(" Cuantos Mirapodes hay de 4 patas??");
        int M4 = teclado.nextInt();
        System.out.println(" CCuantos segmentos tienen?");
        int S4 = teclado.nextInt();

        System.out.println("El numero de patas totales que hay son: ");
        System.out.println( (6 * I) + (8 * A) + (10 * C) + (M2*(S2 * 2)) + (M4*(S4 * 4)) );


        //Ejercicio11
        System.out.println("Que hora es? ");
        int H = teclado.nextInt();
        System.out.println("Que minuto es? ");
        int M = teclado.nextInt();
        System.out.println("Quedan " + ( 1440 - (  H * 60) - M ) + " minutos" );

        //Ejercicio12
        System.out.println("Escribeme un  número de tres cifras enteros: ");
        int numero = teclado.nextInt();
        int centenas = numero / 100;
        int decenas = (numero % 100) / 10 ;
        int unidades = numero % 10;
        System.out.println((unidades * 100) + (decenas * 10) + centenas);

        //Ejercicio13

        System.out.println("Dime un numero: ");
        int n1 = teclado.nextInt();
        System.out.println("Dime otro numero: ");
        int n2 = teclado.nextInt();
        int resultado1 = n1 + n2;
        int resultado2 = resultado1 + n2;
        int resultado3 = resultado2 + resultado1;
        int resultado4 = resultado3 + resultado2;
        int resultado5 = resultado4 + resultado3;
        int resultado6 = resultado5 + resultado4;
        int resultado7 = resultado6 + resultado5;
        System.out.print(n1 + "  ");
        System.out.print(n2 +  "  ");
        System.out.print(resultado1 + "  ");
        System.out.print(resultado2 + "  ");
        System.out.print(resultado3 + "  ");
        System.out.print(resultado4 + "  ");
        System.out.print(resultado5 + "  ");
        System.out.print(resultado6 + "  ");
        System.out.print(resultado7 + "  ");


        //Ejercicio 14
        System.out.println("Indica el ancho de la caja: ");
        int W = teclado.nextInt();
        System.out.println("Indica la altura de la caja: ");
        int H = teclado.nextInt();
        System.out.println("Indica la profundidad de la caja: ");
        int D = teclado.nextInt();
        int resultado = 2 * (W + H) + 2 * (W + D) + 2 * ( H + D) ;

        System.out.println( resultado + " cintas nos haran falta ");

        //Ejercicio15

        System.out.println("Dime el nombre del articulo: ");
        String art = teclado.next();
        System.out.println("Dime precio original: ");
        float prec = teclado.nextFloat();
        System.out.println("Dime el tanto por ciento de la rebaja: ");
        float Reb = teclado.nextFloat();
        System.out.println(art);
        System.out.println("Antes: " + prec + " euros");
        System.out.println("Ahora: " + (  prec  - ((prec * Reb)/100) ) +   " euros");*/

        //Ejercicio16
        int number = 1000;
        boolean result = number + 10 > number + 9;
        System.out.println(result);

        System.out.println(1 + 2 < 3);

        //ñSystem.out.println(1 < 2 < 3);

        System.out.println(1 < 2 + 3);



    }
}